package com.ttn.core.models;

import com.adobe.cq.sightly.WCMUsePojo;
import com.adobe.cq.social.commons.comments.api.CommentSystemSocialComponentFactory;

public class Usetest extends WCMUsePojo {

    private String test;
    @Override
    public void activate() throws Exception {
        test= "ferf";
    }

    public String getTest() {
        return test;
    }
}

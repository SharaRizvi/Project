package com.ttn.core;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Required;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;
import javax.jcr.Node;
import javax.jcr.RepositoryException;

@Model(adaptables= {Resource.class})
public class InsightsModel {

    @Inject
    private List<Resource> insights;

    private List<InsightsBean> insightsBeans;

    @PostConstruct
    void init(){
        try {
            setInsights();
        } catch (RepositoryException e) {
            e.printStackTrace();
        }
    }

    private void setInsights() throws RepositoryException {
        insightsBeans=new ArrayList<>();
        for (Resource ins:insights) {
            String title, pageLink, imgLink, description;
            title=ins.getValueMap().get("title",String.class);
            pageLink=ins.getValueMap().get("pageLink",String.class);
            imgLink=ins.getValueMap().get("imgLink",String.class);
            description=ins.getValueMap().get("description",String.class);
            InsightsBean bean=new InsightsBean();
            bean.setTitle(title);
            bean.setImgLink(imgLink);
            bean.setPageLink(pageLink);
            bean.setDescription(description);
            insightsBeans.add(bean);
        }
    }

    public List<InsightsBean> getInsights() {
        return insightsBeans;
    }


}
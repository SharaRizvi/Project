package com.ttn.core.core;

import com.adobe.cq.sightly.WCMUsePojo;
import org.apache.sling.api.resource.Resource;

import java.util.ArrayList;
import java.util.List;

public class MultipleLinks extends WCMUsePojo {
    public String about;
    public String number, email;
    public String text, copyRightContent, address;
    List<MultiLinksBean> linlkstab2 = new ArrayList();
    List<MultiLinksBean> linlkstab3 = new ArrayList();
    List<MultiLinksBean> linlkstab4 = new ArrayList();
    String validatedlink, result;

    @Override
    public void activate() throws Exception {
        about=getResource().getValueMap().get("about",String.class);
        number=getResource().getValueMap().get("number",String.class);
        email=getResource().getValueMap().get("email",String.class);
        text=getResource().getValueMap().get("text",String.class);
        copyRightContent=getResource().getValueMap().get("copyRightContent",String.class);
        address=getResource().getValueMap().get("address",String.class);

        for (Resource resource : getResource().getChild("linkstab2").getChildren()) {
            result = validate(resource.getValueMap().get("linkaction", String.class));

            linlkstab2.add(new MultiLinksBean(resource.getValueMap().get("linkname", String.class), result));
        }
        for (Resource resource : getResource().getChild("linkstab3").getChildren()) {
            result = validate(resource.getValueMap().get("linkaction", String.class));

            linlkstab3.add(new MultiLinksBean(resource.getValueMap().get("linkname", String.class), result));
        }

        for (Resource resource : getResource().getChild("linkstab4").getChildren()) {
            result = validate(resource.getValueMap().get("linkaction", String.class));

            linlkstab4.add(new MultiLinksBean(resource.getValueMap().get("linkname", String.class), result));
        }
    }

    public String validate(String link) {
        if (link.startsWith("/content")) {
            if (!(link.endsWith(".html"))) {
                validatedlink = link + ".html";
            } else {
                validatedlink = link;
            }
        } else if (!(link.startsWith("https://") || link.startsWith("http://"))) {
            validatedlink = "https://" + link;
        } else {
            validatedlink = link;
        }
        return validatedlink;
    }

    public List<MultiLinksBean> getLinlkstab2() {
        return linlkstab2;
    }

    public List<MultiLinksBean> getLinlkstab3() {
        return linlkstab3;
    }

    public List<MultiLinksBean> getLinlkstab4() {
        return linlkstab4;
    }


}

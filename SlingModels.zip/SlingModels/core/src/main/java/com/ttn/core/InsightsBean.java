package com.ttn.core;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import javax.inject.Inject;

public class InsightsBean {
    private String title;

    private String pageLink;

    private String imgLink;

    private String description;

    public String getTitle() {
        return title;
    }

    public String getImgLink() {
        return imgLink;
    }

    public String getPageLink() {
        return pageLink;
    }

    public String getDescription() {
        return description;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setImgLink(String imgLink) {
        this.imgLink = imgLink;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setPageLink(String pageLink) {
        this.pageLink = pageLink;
    }
}

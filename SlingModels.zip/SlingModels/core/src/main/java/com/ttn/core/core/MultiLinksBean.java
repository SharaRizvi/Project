package com.ttn.core.core;

public class MultiLinksBean {
    String linktext;
    String linktextaction;

    public MultiLinksBean(String linktext, String linktextaction) {
        this.linktext = linktext;
        this.linktextaction = linktextaction;
    }

    public String getLinktext() {
        return linktext;
    }

    public void setLinktext(String linktext) {
        this.linktext = linktext;
    }

    public String getLinktextaction() {
        return linktextaction;
    }

    public void setLinktextaction(String linktextaction) {
        this.linktextaction = linktextaction;
    }
}
